# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['efdet_tfl']

package_data = \
{'': ['*'], 'efdet_tfl': ['images/*', 'weights/*']}

install_requires = \
['opencv-python>=4.6.0,<5.0.0', 'tensorflow>=2.9.1,<3.0.0']

setup_kwargs = {
    'name': 'efdet-tfl',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Alex Byzov',
    'author_email': 'debesergopotes12@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
